$('a.modali').click(function(event) {
  $(this).modal({
    fadeDuration: 500
  });
  return false;
});
